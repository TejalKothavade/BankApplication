package com.cts.bankapplication;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.bankapplication.models.Transaction;
import com.cts.bankapplication.models.UserAccount;
import com.cts.bankapplication.repository.TransactionRepository;
import com.cts.bankapplication.repository.UserAccountRepo;
import com.cts.bankapplication.responce.TransferBalanceRequest;
import com.cts.bankapplication.service.AccountServiceImpl;

@ExtendWith(MockitoExtension.class)
class Transactiontest {

	@InjectMocks
	AccountServiceImpl service;

	@Mock
	UserAccountRepo repo;

	@Mock
	TransactionRepository transRepo;

	@Test
	void Usertest() {
		UserAccount u1 = new UserAccount(1, "1294567899", "Tejal", "ADPEP0514K", LocalDate.of(2003, 04, 14), "salary",
				"active", BigDecimal.valueOf(10000), "6300031404", "kothavadetejal98@gmail.com", 500);
		System.out.println(u1.toString());
		Mockito.when(repo.save(Mockito.any())).thenReturn(u1);

		UserAccount user1 = service.save(u1);
		System.out.println(user1.toString());
		assertEquals("1294567899", user1.getAccountNumber());
		assertEquals("Tejal", user1.getUserName());
		assertEquals("ADPEP0514K", user1.getPANNumber());
		assertEquals(LocalDate.of(2003, 04, 14), user1.getDateOfBirth());
		assertEquals(BigDecimal.valueOf(10000), user1.getAccountBalance());
		assertEquals("6300031404", user1.getPhoneNumber());
		assertEquals("kothavadetejal98@gmail.com", user1.getEmail());

		UserAccount u2 = new UserAccount(2, "1294567898", "Tejal", "ADPEP0514K", LocalDate.of(2003, 04, 14), "salary",
				"active", BigDecimal.valueOf(10000), "6300031404", "kothavadetejal98@gmail.com", 500);
		System.out.println(u2.toString());
		Mockito.when(repo.save(Mockito.any())).thenReturn(u2);

		UserAccount user2 = service.save(u1);
		System.out.println(user2.toString());
		assertEquals("1294567898", user2.getAccountNumber());
		assertEquals("Tejal", user2.getUserName());
		assertEquals("ADPEP0514K", user2.getPANNumber());
		assertEquals(LocalDate.of(2003, 04, 14), user2.getDateOfBirth());
		assertEquals(BigDecimal.valueOf(10000), user2.getAccountBalance());
		assertEquals("6300031404", user2.getPhoneNumber());
		assertEquals("kothavadetejal98@gmail.com", user2.getEmail());

		when(repo.findByAccountNumberEquals(user1.getAccountNumber())).thenReturn(user1);
		when(repo.findByAccountNumberEquals(user2.getAccountNumber())).thenReturn(user2);

		TransferBalanceRequest tbr = new TransferBalanceRequest(user1.getAccountNumber(), user2.getAccountNumber(),
				new BigDecimal(400));
		System.out.println(tbr.toString());
		when(transRepo.save(Mockito.any()))
				.thenReturn(new Transaction(1, "1294567898", "1294567899", "SUCCESS", BigDecimal.valueOf(100), new Date()));
		Transaction tr = service.sendMoney(tbr);
		System.out.println(tr.toString());
		
		assertEquals("1294567898", tbr.getToAccountNumber());
		assertEquals("1294567899", tbr.getFromAccountNumber());
		assertEquals("SUCCESS",tr.getTransactionStatus());
		assertEquals(BigDecimal.valueOf(100),tr.getAmount());
		
		
		
		
		
		

	}

}