package com.cts.bankapplication;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.constraints.Min;
import javax.validation.constraints.Past;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.bankapplication.models.UserAccount;
import com.cts.bankapplication.repository.UserAccountRepo;
import com.cts.bankapplication.service.AccountService;
import com.cts.bankapplication.service.AccountServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
class Usertest {
	@Mock
	private UserAccountRepo accountRepository;
	@InjectMocks
	private AccountServiceImpl service;

	@Test
	void Usertest() {
		UserAccount u = new UserAccount(1, "1294567899", "Tejal", "ADPEP0514K", LocalDate.of(2003, 04, 14), "salary",
				"active", BigDecimal.valueOf(10000), "6300031404", "kothavadetejal98@gmail.com", 500);
		System.out.println(u.toString());
		Mockito.when(accountRepository.save(Mockito.any())).thenReturn(u);

		UserAccount user = service.save(u);
		System.out.println(user.toString());
		assertEquals("1294567899", user.getAccountNumber());
		assertEquals("Tejal", user.getUserName());
		assertEquals("ADPEP0514K", user.getPANNumber());
		assertEquals(LocalDate.of(2003, 04, 14), user.getDateOfBirth());
		assertEquals(BigDecimal.valueOf(10000), user.getAccountBalance());
		assertEquals("6300031404", user.getPhoneNumber());
		assertEquals("kothavadetejal98@gmail.com", user.getEmail());

	}

}
