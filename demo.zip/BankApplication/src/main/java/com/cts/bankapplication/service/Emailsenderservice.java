package com.cts.bankapplication.service;

public interface Emailsenderservice {
	void sendEmail(String to, String subject, String message);

}
