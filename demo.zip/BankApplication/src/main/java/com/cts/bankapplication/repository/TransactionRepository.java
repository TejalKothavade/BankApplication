package com.cts.bankapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.bankapplication.models.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Integer> {
	List<Transaction> findByfromAccountEquals(String accountNumber);
}
