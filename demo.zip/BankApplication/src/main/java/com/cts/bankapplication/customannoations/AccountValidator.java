package com.cts.bankapplication.customannoations;

import java.time.LocalDate;
import java.time.Period;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AccountValidator implements ConstraintValidator<AgeValidator, LocalDate> {

	@Override
	public boolean isValid(LocalDate doj, ConstraintValidatorContext context) {
		LocalDate current = LocalDate.now();
		Period p = Period.between(doj, current);

		if (p.getYears() > 18 && p.getYears() < 60) {
			System.out.println("age of customer is " + p.getYears());
			return true;
		} else if (p.getYears() <= 18) {
			return false;
		} else {
			return false;
		}

	}

}
