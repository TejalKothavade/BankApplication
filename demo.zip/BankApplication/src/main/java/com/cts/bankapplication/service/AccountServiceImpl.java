package com.cts.bankapplication.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cts.bankapplication.model.AccountStatement;
import com.cts.bankapplication.models.Transaction;
import com.cts.bankapplication.models.UserAccount;
import com.cts.bankapplication.repository.TransactionRepository;
import com.cts.bankapplication.repository.UserAccountRepo;
import com.cts.bankapplication.responce.TransferBalanceRequest;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private UserAccountRepo accountRepository;

	@Autowired
	TransactionRepository transactionRepository;

	@Autowired
	private JavaMailSender mailsender;

	public UserAccount save(UserAccount account) {
		// System.out.println(account.getAccountNumber());
		return accountRepository.save(account);

	}

	public List<UserAccount> findAll() {
		return accountRepository.findAll();
	}

	public UserAccount findByAccountNumber(String accountNumber) {
		UserAccount account = accountRepository.findByAccountNumberEquals(accountNumber);
		return account;
	}

	public List<String> listOfEmails() {
		List<UserAccount> accs = getByMab();
		List<String> emails = new ArrayList<String>();
		for (UserAccount userAccount : accs) {

			emails.add(userAccount.getEmail());
		}
		return emails;

	}

	@Override
	public Transaction sendMoney(TransferBalanceRequest transferBalanceRequest) {
		String fromAccountNumber = transferBalanceRequest.getFromAccountNumber();
		String toAccountNumber = transferBalanceRequest.getToAccountNumber();
		BigDecimal amount = transferBalanceRequest.getAmount();
		UserAccount fromAccount = accountRepository.findByAccountNumberEquals(fromAccountNumber);
		UserAccount toAccount = accountRepository.findByAccountNumberEquals(toAccountNumber);
		if (fromAccount.getAccountBalance().compareTo(BigDecimal.ONE) == 1
				&& fromAccount.getAccountBalance().compareTo(amount) == 1) {
			fromAccount.setAccountBalance(fromAccount.getAccountBalance().subtract(amount));
			accountRepository.save(fromAccount);
			toAccount.setAccountBalance(toAccount.getAccountBalance().add(amount));
			accountRepository.save(toAccount);
			Transaction transaction = transactionRepository
					.save(new Transaction(fromAccountNumber, toAccountNumber, "SUCCESS", amount, new Date()));
			return transaction;

		}

		return null;
	}

	@Override
	public AccountStatement getStatement(String accountNumber) {
		UserAccount account = accountRepository.findByAccountNumberEquals(accountNumber);
		return new AccountStatement(account.getAccountBalance(),
				transactionRepository.findByfromAccountEquals(accountNumber));
	}

	public List<UserAccount> getByMab() {

		return accountRepository.findByMonthlyAverageBalance();
	}

	public void sendEmail(String subject, String body) {
		List<String> emails = listOfEmails();
		for (String i : emails) {
			SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
			simpleMailMessage.setFrom("ahirenaina16@gmail.com");
			simpleMailMessage.setTo(i);
			simpleMailMessage.setSubject(subject);
			simpleMailMessage.setText(body);
			this.mailsender.send(simpleMailMessage);
		}

	}

	@Override
	public Transaction save(Transaction transaction) {
		// TODO Auto-generated method stub
		return null;
	}

}
