package com.cts.bankapplication.service;

import java.util.List;
import com.cts.bankapplication.model.AccountStatement;
import com.cts.bankapplication.models.Transaction;
import com.cts.bankapplication.models.UserAccount;
import com.cts.bankapplication.responce.TransferBalanceRequest;

public interface AccountService {
	List<UserAccount> findAll();

	UserAccount save(UserAccount account);

	Transaction save(Transaction transaction);

	Transaction sendMoney(TransferBalanceRequest transferBalanceRequest);

	AccountStatement getStatement(String accountNumber);
}