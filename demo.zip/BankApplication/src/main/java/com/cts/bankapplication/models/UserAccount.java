package com.cts.bankapplication.models;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.cts.bankapplication.customannoations.AgeValidator;

@Entity
@Table(name = "userAccount")

public class UserAccount {

	@Id
	@GeneratedValue
	private Integer customerId;

	@Size(min = 10, max = 10, message = "account should be 10 digits")
	@Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid account number ")
	private String accountNumber;

	@NotEmpty(message = "name should be entered")
	private String userName;

	@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = " enter valid pan number")
	private String PANNumber;

	@Past(message = "enter valid date of birth")
	@AgeValidator()
	private LocalDate DateOfBirth;

	@NotNull(message = "enter valid type")
	private String AccountType;

	@NotNull(message = "enter valid type")
	private String AccountStatus;

	@Min(1)
	private BigDecimal AccountBalance;

	@Pattern(regexp = "[6-9]{1}[0-9]{9}", message = "enter valid phonenumber")
	private String phoneNumber;

	@Email(message = "enter valid email")
	private String email;

	@Min(1)
	private int monthlyAverageBalance;

	public UserAccount() {
		super();
	}

	public UserAccount(Integer customerId,
			@Size(min = 10, max = 10, message = "account should be 10 digits") @Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid account number ") String accountNumber,
			@NotEmpty(message = "name should be entered") String userName,
			@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = " enter valid pan number") String pANNumber,
			@Past(message = "enter valid date of birth") LocalDate dateOfBirth,
			@NotNull(message = "enter valid type") String accountType,
			@NotNull(message = "enter valid type") String accountStatus, @Min(1) BigDecimal accountBalance,
			@Pattern(regexp = "[6-9]{1}[0-9]{9}", message = "enter valid phonenumber") String phoneNumber,
			@Email(message = "enter valid email") String email, @Min(1000) int monthlyAverageBalance) {
		super();
		this.customerId = customerId;
		this.accountNumber = accountNumber;
		this.userName = userName;
		PANNumber = pANNumber;
		DateOfBirth = dateOfBirth;
		AccountType = accountType;
		AccountStatus = accountStatus;
		AccountBalance = accountBalance;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.monthlyAverageBalance = monthlyAverageBalance;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPANNumber() {
		return PANNumber;
	}

	public void setPANNumber(String pANNumber) {
		PANNumber = pANNumber;
	}

	public LocalDate getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	public String getAccountType() {
		return AccountType;
	}

	public void setAccountType(String accountType) {
		AccountType = accountType;
	}

	public String getAccountStatus() {
		return AccountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		AccountStatus = accountStatus;
	}

	public BigDecimal getAccountBalance() {
		return AccountBalance;
	}

	public void setAccountBalance(BigDecimal accountBalance) {
		AccountBalance = accountBalance;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getMonthlyAverageBalance() {
		return monthlyAverageBalance;
	}

	public void setMonthlyAverageBalance(int monthlyAverageBalance) {
		this.monthlyAverageBalance = monthlyAverageBalance;
	}

	@Override
	public String toString() {
		return "UserAccount [customerId=" + customerId + ", accountNumber=" + accountNumber + ", userName=" + userName
				+ ", PANNumber=" + PANNumber + ", DateOfBirth=" + DateOfBirth + ", AccountType=" + AccountType
				+ ", AccountStatus=" + AccountStatus + ", AccountBalance=" + AccountBalance + ", phoneNumber="
				+ phoneNumber + ", email=" + email + ", monthlyAverageBalance=" + monthlyAverageBalance + "]";
	}

}
