package com.cts.bankapplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.bankapplication.models.UserAccount;

@Repository
public interface UserAccountRepo extends JpaRepository<UserAccount, String> {

	UserAccount findByAccountNumberEquals(String accountNumber);

	@Query("SELECT t FROM UserAccount t WHERE t.monthlyAverageBalance>=1000")
	List<UserAccount> findByMonthlyAverageBalance();

}
