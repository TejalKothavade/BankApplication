package com.cts.bankapplication.models;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;

	@Size(min = 10, max = 10, message = "account should be 10 digits")
	@Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid from account number ")

	private String fromAccount;
	@Size(min = 10, max = 10, message = "account should be 10 digits")
	@Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid to account number ")
	private String toAccount;

	private String transactionStatus;

	@Min(0)
	private BigDecimal amount;

	private Date timestamp;

	public Transaction() {

	}

	public Transaction(int transactionId,
			@Size(min = 10, max = 10, message = "account should be 10 digits") @Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid from account number ") String fromAccount,
			@Size(min = 10, max = 10, message = "account should be 10 digits") @Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid to account number ") String toAccount,
			String transactionStatus, @Min(0) BigDecimal amount, Date timestamp) {
		super();
		this.transactionId = transactionId;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.transactionStatus = transactionStatus;
		this.amount = amount;
		this.timestamp = timestamp;
	}

	public Transaction(
			@Size(min = 10, max = 10, message = "account should be 10 digits") @Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid from account number ") String fromAccount,
			@Size(min = 10, max = 10, message = "account should be 10 digits") @Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "enter vadid to account number ") String toAccount,
			String transactionStatus, @Min(0) BigDecimal amount, Date timestamp) {
		super();
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.transactionStatus = transactionStatus;
		this.amount = amount;
		this.timestamp = timestamp;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(String fromAccount) {
		this.fromAccount = fromAccount;
	}

	public String getToAccount() {
		return toAccount;
	}

	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", fromAccount=" + fromAccount + ", toAccount="
				+ toAccount + ", transactionStatus=" + transactionStatus + ", amount=" + amount + ", timestamp="
				+ timestamp + "]";
	}

}
