package com.cts.bankapplication.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bankapplication.resource.Emailmessage;
import com.cts.bankapplication.service.Emailsenderservice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class Emailcontroller {

	private Emailsenderservice emailsenderservice;

	public Emailcontroller(Emailsenderservice emailsenderservice) {
		this.emailsenderservice = emailsenderservice;
	}

	@PostMapping("/send-email")
	public ResponseEntity sendEmail(@RequestBody Emailmessage emailmessage) {
		this.emailsenderservice.sendEmail(emailmessage.getTo(), emailmessage.getSubject(), emailmessage.getMessage());
		return ResponseEntity.ok("success");
	}

}
